<?php
/* erko™ framework ~ an evolving, robust platform for rapid & efficient development of modem responsive static or dynamic website;
 * Built by DeronEllse™ [@deronellse - www.deronellse.com/about] using PHP, MySQL, HTML, CSS, JS & derived technology.
 * © February 2016 | version 1.0
 * ===================================================================================================================
 * Dependency »
 * PHP | root::index ~ default file
 */
require('build/config.php');
erko::doctype();?>
<html lang="en">
<head>
<?php
	erko::charset();
	erko::xua_compatible();
	erko::viewport();
	erko::title();
	erko::meta('erko', 'yeah');
	erko::favicon();
	erko::css('device');
	if(validate_ie('==', 6)){echo '<link rel="stylesheet" type="text/css" href="'.path_to('css').'les-ie6.css">';}
	if(!validate_ie('<', 6)){erko::js();}
?>
</head>

<body>
<?php
	erko::heading();	
	if(validate_ie('<', 6)){stale_browser('ie');}
	else {erko::layout();}
?>
</body>
</html>